import os
from collections import defaultdict

dir_path = r"c:\Users\qyzj1\Desktop\MD\ball.v6i.yolo26\test\labels"
target_indices = {'0', '1', '2', '10', '15', '20', '30'}
results = defaultdict(set)

for filename in os.listdir(dir_path):
    if filename.endswith(".txt"):
        filepath = os.path.join(dir_path, filename)
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split()
                if parts and parts[0] in target_indices:
                    results[parts[0]].add(filename)

for idx in sorted(list(target_indices), key=int):
    print(f"## 索引 {idx}")
    if not results[idx]:
        print("  （无）")
    for fname in sorted(list(results[idx])):
        print(f"  - {fname}")
